﻿
namespace BZD
{
    partial class 设置
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BottomToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.TopToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.RightToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.LeftToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.ContentPanel = new System.Windows.Forms.ToolStripContentPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.domainUpDown2 = new System.Windows.Forms.DomainUpDown();
            this.domainUpDown1 = new System.Windows.Forms.DomainUpDown();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BottomToolStripPanel
            // 
            this.BottomToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.BottomToolStripPanel.Name = "BottomToolStripPanel";
            this.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.BottomToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.BottomToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // TopToolStripPanel
            // 
            this.TopToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.TopToolStripPanel.Name = "TopToolStripPanel";
            this.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.TopToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.TopToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // RightToolStripPanel
            // 
            this.RightToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.RightToolStripPanel.Name = "RightToolStripPanel";
            this.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.RightToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.RightToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // LeftToolStripPanel
            // 
            this.LeftToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.LeftToolStripPanel.Name = "LeftToolStripPanel";
            this.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.LeftToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.LeftToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // ContentPanel
            // 
            this.ContentPanel.AutoScroll = true;
            this.ContentPanel.Size = new System.Drawing.Size(617, 423);
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Location = new System.Drawing.Point(530, 412);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "保存设置";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "窗口无焦点时透明度：";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(409, 412);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(99, 23);
            this.button2.TabIndex = 8;
            this.button2.Text = "写入开机启动";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // domainUpDown2
            // 
            this.domainUpDown2.Items.Add("1");
            this.domainUpDown2.Items.Add("0.99");
            this.domainUpDown2.Items.Add("0.98");
            this.domainUpDown2.Items.Add("0.97");
            this.domainUpDown2.Items.Add("0.96");
            this.domainUpDown2.Items.Add("0.95");
            this.domainUpDown2.Items.Add("0.94");
            this.domainUpDown2.Items.Add("0.93");
            this.domainUpDown2.Items.Add("0.92");
            this.domainUpDown2.Items.Add("0.91");
            this.domainUpDown2.Items.Add("0.90");
            this.domainUpDown2.Items.Add("0.89");
            this.domainUpDown2.Items.Add("0.88");
            this.domainUpDown2.Items.Add("0.87");
            this.domainUpDown2.Items.Add("0.86");
            this.domainUpDown2.Items.Add("0.85");
            this.domainUpDown2.Items.Add("0.84");
            this.domainUpDown2.Items.Add("0.83");
            this.domainUpDown2.Items.Add("0.82");
            this.domainUpDown2.Items.Add("0.81");
            this.domainUpDown2.Items.Add("0.80");
            this.domainUpDown2.Items.Add("0.79");
            this.domainUpDown2.Items.Add("0.78");
            this.domainUpDown2.Items.Add("0.77");
            this.domainUpDown2.Items.Add("0.76");
            this.domainUpDown2.Items.Add("0.75");
            this.domainUpDown2.Items.Add("0.74");
            this.domainUpDown2.Items.Add("0.73");
            this.domainUpDown2.Items.Add("0.72");
            this.domainUpDown2.Items.Add("0.71");
            this.domainUpDown2.Items.Add("0.70");
            this.domainUpDown2.Items.Add("0.69");
            this.domainUpDown2.Items.Add("0.68");
            this.domainUpDown2.Items.Add("0.67");
            this.domainUpDown2.Items.Add("0.66");
            this.domainUpDown2.Items.Add("0.65");
            this.domainUpDown2.Items.Add("0.64");
            this.domainUpDown2.Items.Add("0.63");
            this.domainUpDown2.Items.Add("0.62");
            this.domainUpDown2.Items.Add("0.61");
            this.domainUpDown2.Items.Add("0.60");
            this.domainUpDown2.Items.Add("0.59");
            this.domainUpDown2.Items.Add("0.58");
            this.domainUpDown2.Items.Add("0.57");
            this.domainUpDown2.Items.Add("0.56");
            this.domainUpDown2.Items.Add("0.55");
            this.domainUpDown2.Items.Add("0.54");
            this.domainUpDown2.Items.Add("0.53");
            this.domainUpDown2.Items.Add("0.52");
            this.domainUpDown2.Items.Add("0.51");
            this.domainUpDown2.Items.Add("0.50");
            this.domainUpDown2.Items.Add("0.49");
            this.domainUpDown2.Items.Add("0.48");
            this.domainUpDown2.Items.Add("0.47");
            this.domainUpDown2.Items.Add("0.46");
            this.domainUpDown2.Items.Add("0.45");
            this.domainUpDown2.Items.Add("0.44");
            this.domainUpDown2.Items.Add("0.43");
            this.domainUpDown2.Items.Add("0.42");
            this.domainUpDown2.Items.Add("0.41");
            this.domainUpDown2.Items.Add("0.40");
            this.domainUpDown2.Items.Add("0.39");
            this.domainUpDown2.Items.Add("0.38");
            this.domainUpDown2.Items.Add("0.37");
            this.domainUpDown2.Items.Add("0.36");
            this.domainUpDown2.Items.Add("0.35");
            this.domainUpDown2.Items.Add("0.34");
            this.domainUpDown2.Items.Add("0.33");
            this.domainUpDown2.Items.Add("0.32");
            this.domainUpDown2.Items.Add("0.31");
            this.domainUpDown2.Items.Add("0.30");
            this.domainUpDown2.Items.Add("0.29");
            this.domainUpDown2.Items.Add("0.28");
            this.domainUpDown2.Items.Add("0.27");
            this.domainUpDown2.Items.Add("0.26");
            this.domainUpDown2.Items.Add("0.25");
            this.domainUpDown2.Items.Add("0.24");
            this.domainUpDown2.Items.Add("0.23");
            this.domainUpDown2.Items.Add("0.22");
            this.domainUpDown2.Items.Add("0.21");
            this.domainUpDown2.Items.Add("0.20");
            this.domainUpDown2.Items.Add("0.19");
            this.domainUpDown2.Items.Add("0.18");
            this.domainUpDown2.Items.Add("0.17");
            this.domainUpDown2.Items.Add("0.16");
            this.domainUpDown2.Items.Add("0.15");
            this.domainUpDown2.Items.Add("0.14");
            this.domainUpDown2.Items.Add("0.13");
            this.domainUpDown2.Items.Add("0.12");
            this.domainUpDown2.Items.Add("0.11");
            this.domainUpDown2.Items.Add("0.10");
            this.domainUpDown2.Items.Add("0.09");
            this.domainUpDown2.Items.Add("0.08");
            this.domainUpDown2.Items.Add("0.07");
            this.domainUpDown2.Items.Add("0.06");
            this.domainUpDown2.Items.Add("0.05");
            this.domainUpDown2.Items.Add("0.04");
            this.domainUpDown2.Items.Add("0.03");
            this.domainUpDown2.Items.Add("0.02");
            this.domainUpDown2.Items.Add("0.01");
            this.domainUpDown2.Location = new System.Drawing.Point(143, 45);
            this.domainUpDown2.Name = "domainUpDown2";
            this.domainUpDown2.ReadOnly = true;
            this.domainUpDown2.Size = new System.Drawing.Size(120, 21);
            this.domainUpDown2.TabIndex = 5;
            // 
            // domainUpDown1
            // 
            this.domainUpDown1.Items.Add("1");
            this.domainUpDown1.Items.Add("0.99");
            this.domainUpDown1.Items.Add("0.98");
            this.domainUpDown1.Items.Add("0.97");
            this.domainUpDown1.Items.Add("0.96");
            this.domainUpDown1.Items.Add("0.95");
            this.domainUpDown1.Items.Add("0.94");
            this.domainUpDown1.Items.Add("0.93");
            this.domainUpDown1.Items.Add("0.92");
            this.domainUpDown1.Items.Add("0.91");
            this.domainUpDown1.Items.Add("0.90");
            this.domainUpDown1.Items.Add("0.89");
            this.domainUpDown1.Items.Add("0.88");
            this.domainUpDown1.Items.Add("0.87");
            this.domainUpDown1.Items.Add("0.86");
            this.domainUpDown1.Items.Add("0.85");
            this.domainUpDown1.Items.Add("0.84");
            this.domainUpDown1.Items.Add("0.83");
            this.domainUpDown1.Items.Add("0.82");
            this.domainUpDown1.Items.Add("0.81");
            this.domainUpDown1.Items.Add("0.80");
            this.domainUpDown1.Items.Add("0.79");
            this.domainUpDown1.Items.Add("0.78");
            this.domainUpDown1.Items.Add("0.77");
            this.domainUpDown1.Items.Add("0.76");
            this.domainUpDown1.Items.Add("0.75");
            this.domainUpDown1.Items.Add("0.74");
            this.domainUpDown1.Items.Add("0.73");
            this.domainUpDown1.Items.Add("0.72");
            this.domainUpDown1.Items.Add("0.71");
            this.domainUpDown1.Items.Add("0.70");
            this.domainUpDown1.Items.Add("0.69");
            this.domainUpDown1.Items.Add("0.68");
            this.domainUpDown1.Items.Add("0.67");
            this.domainUpDown1.Items.Add("0.66");
            this.domainUpDown1.Items.Add("0.65");
            this.domainUpDown1.Items.Add("0.64");
            this.domainUpDown1.Items.Add("0.63");
            this.domainUpDown1.Items.Add("0.62");
            this.domainUpDown1.Items.Add("0.61");
            this.domainUpDown1.Items.Add("0.60");
            this.domainUpDown1.Items.Add("0.59");
            this.domainUpDown1.Items.Add("0.58");
            this.domainUpDown1.Items.Add("0.57");
            this.domainUpDown1.Items.Add("0.56");
            this.domainUpDown1.Items.Add("0.55");
            this.domainUpDown1.Items.Add("0.54");
            this.domainUpDown1.Items.Add("0.53");
            this.domainUpDown1.Items.Add("0.52");
            this.domainUpDown1.Items.Add("0.51");
            this.domainUpDown1.Items.Add("0.50");
            this.domainUpDown1.Items.Add("0.49");
            this.domainUpDown1.Items.Add("0.48");
            this.domainUpDown1.Items.Add("0.47");
            this.domainUpDown1.Items.Add("0.46");
            this.domainUpDown1.Items.Add("0.45");
            this.domainUpDown1.Items.Add("0.44");
            this.domainUpDown1.Items.Add("0.43");
            this.domainUpDown1.Items.Add("0.42");
            this.domainUpDown1.Items.Add("0.41");
            this.domainUpDown1.Items.Add("0.40");
            this.domainUpDown1.Items.Add("0.39");
            this.domainUpDown1.Items.Add("0.38");
            this.domainUpDown1.Items.Add("0.37");
            this.domainUpDown1.Items.Add("0.36");
            this.domainUpDown1.Items.Add("0.35");
            this.domainUpDown1.Items.Add("0.34");
            this.domainUpDown1.Items.Add("0.33");
            this.domainUpDown1.Items.Add("0.32");
            this.domainUpDown1.Items.Add("0.31");
            this.domainUpDown1.Items.Add("0.30");
            this.domainUpDown1.Items.Add("0.29");
            this.domainUpDown1.Items.Add("0.28");
            this.domainUpDown1.Items.Add("0.27");
            this.domainUpDown1.Items.Add("0.26");
            this.domainUpDown1.Items.Add("0.25");
            this.domainUpDown1.Items.Add("0.24");
            this.domainUpDown1.Items.Add("0.23");
            this.domainUpDown1.Items.Add("0.22");
            this.domainUpDown1.Items.Add("0.21");
            this.domainUpDown1.Items.Add("0.20");
            this.domainUpDown1.Items.Add("0.19");
            this.domainUpDown1.Items.Add("0.18");
            this.domainUpDown1.Items.Add("0.17");
            this.domainUpDown1.Items.Add("0.16");
            this.domainUpDown1.Items.Add("0.15");
            this.domainUpDown1.Items.Add("0.14");
            this.domainUpDown1.Items.Add("0.13");
            this.domainUpDown1.Items.Add("0.12");
            this.domainUpDown1.Items.Add("0.11");
            this.domainUpDown1.Items.Add("0.10");
            this.domainUpDown1.Items.Add("0.09");
            this.domainUpDown1.Items.Add("0.08");
            this.domainUpDown1.Items.Add("0.07");
            this.domainUpDown1.Items.Add("0.06");
            this.domainUpDown1.Items.Add("0.05");
            this.domainUpDown1.Items.Add("0.04");
            this.domainUpDown1.Items.Add("0.03");
            this.domainUpDown1.Items.Add("0.02");
            this.domainUpDown1.Items.Add("0.01");
            this.domainUpDown1.Location = new System.Drawing.Point(143, 12);
            this.domainUpDown1.Name = "domainUpDown1";
            this.domainUpDown1.ReadOnly = true;
            this.domainUpDown1.Size = new System.Drawing.Size(120, 21);
            this.domainUpDown1.TabIndex = 2;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Checked = true;
            this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox2.Location = new System.Drawing.Point(14, 72);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(168, 16);
            this.checkBox2.TabIndex = 8;
            this.checkBox2.Text = "窗口失去焦点是否自动缩放";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "窗口有焦点时透明度：";
            // 
            // 设置
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(617, 448);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.domainUpDown1);
            this.Controls.Add(this.domainUpDown2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "设置";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "设置";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.设置_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripPanel BottomToolStripPanel;
        private System.Windows.Forms.ToolStripPanel TopToolStripPanel;
        private System.Windows.Forms.ToolStripPanel RightToolStripPanel;
        private System.Windows.Forms.ToolStripPanel LeftToolStripPanel;
        private System.Windows.Forms.ToolStripContentPanel ContentPanel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DomainUpDown domainUpDown2;
        private System.Windows.Forms.DomainUpDown domainUpDown1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Label label1;
    }
}